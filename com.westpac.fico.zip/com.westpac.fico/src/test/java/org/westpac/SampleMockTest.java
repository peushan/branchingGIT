package org.westpac;

import base.BaseRestConfig;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.Test;

public class SampleMockTest extends BaseRestConfig {

    @Test
    public void mockingTest() {
        RequestSpecification requestSpecification = new BaseRestConfig().getRequestSpecification();
        response = getJsonPlaceHolder(requestSpecification);
        System.out.println(response.asString());
    }
}
