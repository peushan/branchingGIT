package base;

import com.github.tomakehurst.wiremock.client.ResponseDefinitionBuilder;
import com.github.tomakehurst.wiremock.client.WireMock;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeSuite;
import com.github.tomakehurst.wiremock.WireMockServer;

public class BaseRestConfig {

    protected Response response;
    private static final int PORT = 8080;
    private static final String HOST = "localhost";
    private static WireMockServer wireMockServer = new WireMockServer(PORT);


    @BeforeSuite
    public void config() {
        //RestAssured.baseURI = "https://jsonplaceholder.typicode.com";
        wireMockServer.start();
        ResponseDefinitionBuilder mockResponse = new ResponseDefinitionBuilder();
        mockResponse.withStatus(200)
                .withBody("[{\"BrandName\":\"Alienware\",\"Features\":{\"Feature\":[\"8th Generation Intel® Core™ i5-8300H\",\"Windows 10 Home 64-bit English\",\"NVIDIA® GeForce® GTX 1660 Ti 6GB GDDR6\",\"8GB, 2x4GB, DDR4, 2666MHz\"]},\"Id\":1,\"LaptopName\":\"Alienware M17\"}]")
                .withHeader("Content-Type", "application/json");


        WireMock.configureFor(HOST, PORT);
        WireMock.stubFor(
                WireMock.get("/todos/1")
                        .willReturn(mockResponse)


        );
    }

    public RequestSpecification getRequestSpecification() {
        return RestAssured.given().contentType(ContentType.JSON);
    }


    protected Response getJsonPlaceHolder(RequestSpecification requestSpecification) {
        requestSpecification.header("Content-Type", "application/json");
        response = requestSpecification.get("/todos/1");
        return response;
    }


    @AfterClass
    public static void teardown() {
        if (null != wireMockServer && wireMockServer.isRunning()) {
            wireMockServer.shutdownServer();
        }
    }
}
