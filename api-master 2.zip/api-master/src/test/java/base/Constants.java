package base;

public class Constants {

    public static final String STAFF = "staff";
    public static final String CUSTOMER = "customer";

}
