package kiwibank;

public class Token {
}
