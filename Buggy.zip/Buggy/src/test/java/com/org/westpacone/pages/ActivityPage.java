package com.org.westpacone.pages;

import com.microsoft.playwright.Page;
import org.springframework.stereotype.Component;

@Component
public class ActivityPage {

    public void settings(Page page){
        page.locator("//div[@title='Open settings']").click();
        page.locator("//a[@title='View your profile setting'][0]").selectOption("Profile settings");

    }
}
