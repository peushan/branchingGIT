package com.org.westpacone.base;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Playwright;


public class BrowserFactory extends BaseTest {

    private static final String CHROME = "CHROME";
    private static final String FIREFOX = "FIREFOX";


    public Browser selectBrowser(String BroType) {
        playwright = Playwright.create();
        switch (BroType) {
            case CHROME:
                browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
                break;
            case FIREFOX:
                browser = playwright.firefox().launch(new BrowserType.LaunchOptions().setHeadless(false));
                break;
            default:
                browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
                break;
        }
        return browser;
    }

}
