package com.org.westpacone.base;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Value;

public class BaseTest {

    @Value("${application.url}")
    private String baseURL;
    @Value("${browser}")
    private String browserType;

    protected static BrowserContext context;
    protected static Page page;
    protected static Browser browser;
    protected Playwright playwright;


    @BeforeEach
    public void init() {
        BrowserFactory browserFactory = new BrowserFactory();
        browserFactory.selectBrowser(browserType);
        context = browser.newContext();
        page = context.newPage();
        page.navigate(baseURL);
    }

    @AfterAll
    public static void teardown() {
        browser.close();
    }
}
