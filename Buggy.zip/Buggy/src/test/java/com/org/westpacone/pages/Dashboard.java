package com.org.westpacone.pages;

import com.microsoft.playwright.Page;
import org.springframework.stereotype.Component;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;


@Component
public class Dashboard {

    public void navigateLogin(Page page) {
        page.locator("#login-button").click();
        assertThat(page.locator("//h1[@class='sp-h__page--primary sp-u-margin-top--lg sp-u-margin-bottom--xl']")).hasText("Log in");
    }
}
