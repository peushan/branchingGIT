package com.org.westpacone.tests;

import com.org.westpacone.base.BaseTest;
import com.org.westpacone.pages.ActivityPage;
import com.org.westpacone.pages.Dashboard;
import com.org.westpacone.pages.LoginPage;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WestpacOneApplicationTests extends BaseTest {

    @Autowired
    LoginPage loginPage;
    @Autowired
    Dashboard dashboard;
    @Autowired
    ActivityPage activityPage;

    @Test
    public void applicationOpen() {
        dashboard.navigateLogin(page);
        loginPage.enterCredentials(page);
        activityPage.settings(page);

    }
}
