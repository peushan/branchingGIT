package com.org.westpacone.pages;

import com.microsoft.playwright.Page;
import org.springframework.stereotype.Component;

@Component
public class LoginPage {

    public void enterCredentials(Page page) {
        page.locator("#user_email").type("peushanpanagoda@gmail.com");
        page.locator("#user_password").type("1qaz2wsx@");
        page.locator("//a[@data-action='signin']").click();

    }
}
