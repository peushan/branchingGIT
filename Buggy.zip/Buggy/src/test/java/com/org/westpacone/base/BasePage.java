package com.org.westpacone.base;

import com.microsoft.playwright.Page;
import org.springframework.stereotype.Component;

@Component
public class BasePage {

    public Page page;


}
